This little free add-on was made by rathros, who's also made a whole new outfit for the Character Base (sold separately).

You can check out his page on itch.io here: https://rathros.itch.io/